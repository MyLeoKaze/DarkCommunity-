import os 
import time

x = 1
while x != 0:
	pass
	os.system("curl -s https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt -o utils/proxy.txt")
	time.sleep(600)