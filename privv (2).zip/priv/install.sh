sudo apt update && curl -sL https://deb.nodesource.com/setup_16.x | sudo bash - && sudo apt -y install nodejs && python3 sky.py
